package com.example.capstone_project_tripease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
